/**
 * Created by robert on 9/3/14.
 * http://curator.apache.org/curator-framework/
 */

import java.io.Closeable;
import java.io.File;
import java.io.IOException;
import java.lang.reflect.Field;
import java.util.Collection;
import java.util.List;

import javax.swing.text.MaskFormatter;

import junit.framework.Assert;

import org.apache.curator.RetryPolicy;
import org.apache.curator.framework.api.CreateBuilder;
import org.apache.curator.framework.api.CuratorListener;
import org.apache.curator.framework.api.transaction.CuratorTransaction;
import org.apache.curator.framework.api.transaction.CuratorTransactionFinal;
import org.apache.curator.framework.api.transaction.CuratorTransactionResult;
import org.apache.curator.framework.recipes.cache.ChildData;
import org.apache.curator.framework.recipes.cache.PathChildrenCache;
import org.apache.curator.framework.state.ConnectionState;
import org.apache.curator.framework.CuratorFramework;
import org.apache.curator.framework.CuratorFrameworkFactory;
import org.apache.curator.retry.ExponentialBackoffRetry;
import org.apache.curator.test.*;
import org.apache.curator.utils.CloseableUtils;
import org.apache.curator.utils.EnsurePath;
import org.apache.curator.utils.ZKPaths;
import org.apache.zookeeper.KeeperException;
import org.apache.zookeeper.WatchedEvent;
import org.apache.zookeeper.Watcher;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import static java.lang.String.*;
import static org.apache.curator.framework.CuratorFrameworkFactory.*;

public class ZkManager {
    CuratorFramework client = null;
    private static final Logger logger = LoggerFactory.getLogger(ZkManager.class);

    public ZkManager(String connectString) {    //don't touch !
        client = CuratorFrameworkFactory.newClient(connectString, new ExponentialBackoffRetry(1000, 3));    //don't touch !
        client.start(); //don't touch !
    }

    public void createPath(String path) {   //don't touch !
        try {
            client.create().creatingParentsIfNeeded().forPath(path);
            //client.create().forPath(path, new byte[0]);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public List<String> readPath(String path) { //don't touch !
        /**
         * TODO: recursively read
         */

        try {
            return client.getChildren().forPath(path);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

}