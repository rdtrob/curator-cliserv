/**
 * Never use logs in JUnit tests, instead, use only asserts
 *
 * JUnit class is done!, fix ZkManager
 */

import org.apache.curator.test.TestingServer;
import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import java.io.File;
import java.io.IOException;
import java.net.BindException;
import java.util.List;
import java.util.concurrent.atomic.AtomicBoolean;

import static org.apache.curator.test.DirectoryUtils.deleteDirectoryContents;
import static org.junit.Assert.assertEquals;

/**
 * Created by robert on 9/3/14.
 */
public class ZkManagerTest {
    private TestingServer server;
    private static final int RETRY_WAIT_MS = 5000;

    @Before // Create server
    public void createServer() throws Exception {
        while (server == null) {
            try {
                server = new TestingServer();
            } catch (Exception e) {
                System.err.println("> Exception, retrying to create server. <");
                server = null;
            }
        }
    }

    @After  // Kill server
    public void killServer() throws Exception {   //don't touch !
        if(server != null) {
            try {
                server.stop();
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }

    @Test
    public void testCreatePath() {   //don't touch !
        ZkManager manager = new ZkManager(server.getConnectString());
        manager.createPath("/tmp/a");
        manager.createPath("/tmp/b/n");
        manager.createPath("/tmp/x/y/f");
        manager.createPath("/tmp/b/a/c");
        manager.createPath("/tmp/a/b");
        List<String> folders = manager.readPath("/tmp");
        /*
        print all paths(directories ... aka nodes!) in the above List<String> ...
        Asserts for each create path in this test
         */
        Assert.assertTrue(folders.contains("a"));
    }

 }